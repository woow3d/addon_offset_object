bl_info = {
    "name": "Offset Objects By Name (Axis + MM)",
    "author": "Simple Code",
    "version": (1, 2, 0),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar > Offset",
    "description": "Offset objects by variable mm and axis based on active object name",
    "category": "Object",
}

import bpy


# ---------- Properties ----------
class OffsetSettings(bpy.types.PropertyGroup):

    offset_mm: bpy.props.FloatProperty(
        name="Offset (mm)",
        description="Distance between objects in millimeters",
        default=20.0,
        min=0.0,
        precision=2
    )

    axis: bpy.props.EnumProperty(
        name="Axis",
        description="Axis to offset on",
        items=[
            ('X', "X", "Offset on X axis"),
            ('Y', "Y", "Offset on Y axis"),
            ('Z', "Z", "Offset on Z axis"),
        ],
        default='X'
    )


# ---------- Utils ----------
def get_objects_by_active_name(context):
    active = context.active_object
    if not active:
        return []

    base_name = active.name.split('.')[0]
    objs = [
        obj for obj in context.scene.objects
        if obj.name.startswith(base_name + ".")
    ]
    objs.sort(key=lambda o: o.name)
    return objs


def apply_offset(obj, axis, value):
    if axis == 'X':
        obj.location.x += value
    elif axis == 'Y':
        obj.location.y += value
    elif axis == 'Z':
        obj.location.z += value


# ---------- Operators ----------
class OBJECT_OT_offset_plus(bpy.types.Operator):
    bl_idname = "object.offset_plus_mm"
    bl_label = "Offset +"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.offset_settings
        offset = settings.offset_mm / 1000  # mm → meters

        objects = get_objects_by_active_name(context)
        for i, obj in enumerate(objects):
            apply_offset(obj, settings.axis, offset * (i + 1))

        return {'FINISHED'}


class OBJECT_OT_offset_minus(bpy.types.Operator):
    bl_idname = "object.offset_minus_mm"
    bl_label = "Offset -"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.offset_settings
        offset = settings.offset_mm / 1000  # mm → meters

        objects = get_objects_by_active_name(context)
        for i, obj in enumerate(objects):
            apply_offset(obj, settings.axis, -(offset * (i + 1)))

        return {'FINISHED'}


# ---------- UI Panel ----------
class VIEW3D_PT_offset_panel(bpy.types.Panel):
    bl_label = "Offset By Name"
    bl_idname = "VIEW3D_PT_offset_by_name"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Offset"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.offset_settings

        layout.prop(settings, "offset_mm")
        layout.prop(settings, "axis", expand=True)
        layout.separator()
        layout.operator("object.offset_plus_mm", icon='ADD')
        layout.operator("object.offset_minus_mm", icon='REMOVE')


# ---------- Register ----------
classes = (
    OffsetSettings,
    OBJECT_OT_offset_plus,
    OBJECT_OT_offset_minus,
    VIEW3D_PT_offset_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.offset_settings = bpy.props.PointerProperty(
        type=OffsetSettings
    )


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

    del bpy.types.Scene.offset_settings


if __name__ == "__main__":
    register()
